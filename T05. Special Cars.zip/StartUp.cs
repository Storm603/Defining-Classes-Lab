﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            List<Tire[]> tireList = new List<Tire[]>();
            List<Engine> engineList = new List<Engine>();
            List<Car> carList = new List<Car>();

            while (input != "No more tires")
            {
                string[] split = input.Split();
                Tire[] tires =
                {
                    new Tire(int.Parse(split[0]), double.Parse(split[1])),
                    new Tire(int.Parse(split[2]), double.Parse(split[3])),
                    new Tire(int.Parse(split[4]), double.Parse(split[5])),
                    new Tire(int.Parse(split[6]), double.Parse(split[7]))
                };

                tireList.Add(tires);

                input = Console.ReadLine();
            }

            input = Console.ReadLine();

            while (input != "Engines done")
            {
                string[] split = input.Split();
                Engine engine = new Engine(int.Parse(split[0]), double.Parse(split[1]));
                engineList.Add(engine);

                input = Console.ReadLine();
            }

            input = Console.ReadLine();

            while (input != "Show special")
            {
                string[] split = input.Split();

                string make = split[0];
                string model = split[1];
                int year = int.Parse(split[2]);
                double fuelQuanityt = double.Parse(split[3]);
                double fuelConsumption = double.Parse(split[4]);
                int engineIndex = int.Parse(split[5]);
                int tiresIndex = int.Parse(split[6]);

                Car car = new Car(make, model, year, fuelQuanityt, fuelConsumption, engineList[engineIndex], tireList[tiresIndex]);
                
                carList.Add(car);

                input = Console.ReadLine();
            }

            foreach (Car car in carList)
            {
                double sumTirePressure = 0;

                foreach (Tire carTire in car.Tires)
                {
                    sumTirePressure += carTire.Pressure;
                }

                if (car.Year >= 2017 && car.Engine.HorsePower  > 330 && sumTirePressure >= 9 && sumTirePressure <= 10)
                {
                    car.FuelQuantity -= 20 * (car.FuelConsumption / 100);

                    Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}\nHorsePowers: {car.Engine.HorsePower}\nFuelQuantity: {car.FuelQuantity}");
                }
            }

            //Tire[] tires = new Tire[4]
            //{
            //    new Tire(1, 2.5),
            //    new Tire(1, 2.1),
            //    new Tire(2, 0.5),
            //    new Tire(2, 2.3)
            //};
            //Console.WriteLine(tires[1].Pressure + " " + tires[1].Year);
            //Engine engine = new Engine(560, 6300);

            //Car car = new Car("Lamborghini", "Urus", 2010, 250, 9, engine, tires);
        }
    }
}
