﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace CarManufacturer
{
    class Car
    {
        private string make;
        private string model;
        private int year;
        private double fuelQuantity;
        private double fuelConsumption;

        public string Make
        {
            get { return make;}
            set { make = value; }
        }
            
        public string Model
        {
            get { return model;}
            set { model = value; }
        }

        public int Year
        {
            get { return year;}
            set { year = value; }
        }

        public double FuelQuantity
        {
            get { return fuelQuantity;}
            set { fuelQuantity = value; }
        }
        public double FuelConsumption
        {
            get { return fuelConsumption; }
            set { fuelConsumption = value; }
        }

        public Car()
        {
            Make = "VW";
            Model = "Golf";
            Year = 2025;
            FuelQuantity = 200;
            FuelConsumption = 10;
        }

        public Car(string Make, string Model, int Year) : this()
        {
            this.make = Make;
            this.model = Model;
            year = Year;
        }

        public Car(string Make, string Model, int Year, double fuelQuantity, double fuelConsumption) : this(Make, Model, Year)
        {
            this.fuelQuantity = fuelQuantity;
            this.fuelConsumption = fuelConsumption;
        }
    }
}
